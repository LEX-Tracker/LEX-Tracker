package com.lex.ui

import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView.OnItemClickListener
import android.widget.CalendarView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.lex.MainActivity
import com.lex.R
import com.lex.SharedPrefs
import com.lex.calender.CalendarCustomView
import com.lex.calender.EventObjects
import com.lex.databinding.FragmentHomeBinding
import com.lex.models.MyViewModel
import com.lex.models.SymptomModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.Dispatchers.Main
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*


class HomeFragment : Fragment(), CalendarView.OnDateChangeListener {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding
    private lateinit var callback: OnBackPressedCallback
    var exit: Boolean = false
    lateinit var countDown: CountDownTimer
    var listData = arrayListOf<SymptomModel>()
    var selectedDates: List<Date>? = null
    var start: Date? = null
    var end: Date? = null
    var initialDate: Date? = null
    var lastDate: Date? = null

    var startDay: Int = 0
    var oneTime: Boolean = true
    lateinit var prefs: SharedPrefs
    val args: HomeFragmentArgs by navArgs()


    val myViewModel: MyViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        prefs = SharedPrefs(requireContext())

        myViewModel.readAllData.observe(viewLifecycleOwner) {
            if (it.stream().anyMatch { it.date != "" }) {
                listData.addAll(it)
            }
        }
        return binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fragmentBackPress()

        binding?.ivHome?.setOnClickListener {}
        binding?.ivSymptoms?.setOnClickListener {
            moveToNext("Symptoms")
        }
        binding?.ivSettings?.setOnClickListener {
            moveToNext("Settings")
        }

        binding?.calenderV?.setOnDateChangeListener(this)

        var calendar: Calendar = Calendar.getInstance()
        calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DATE))
        val endOfMonth: Long = calendar.timeInMillis
        calendar = Calendar.getInstance()
        calendar.set(Calendar.DATE, 1)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        val startOfMonth: Long = calendar.timeInMillis
        binding?.calenderV?.maxDate = endOfMonth
        binding?.calenderV?.minDate = startOfMonth

        //new layout
        val mEvents: MutableList<EventObjects> = ArrayList<EventObjects>()
        //Custom Events

        val yellow = ContextCompat.getColor(requireContext(), R.color.darkYellow)
        val green = ContextCompat.getColor(requireContext(), R.color.green)

        val pms = ContextCompat.getColor(requireContext(), R.color.pms)
        val ov = ContextCompat.getColor(requireContext(), R.color.ov)

        CoroutineScope(IO).launch {
            delay(1000)
            if (args.fromWhichPin == "firstPin" && !LockFragment.isSecondaryPin) {
                listData.forEach {
                    if (it.date != "") {
                        val date = it.date?.let { it1 -> dateFormat(it1) }

                        if (oneTime) {
                            startDay = it.date?.substringBefore(" ")?.toInt()!!
                            oneTime = false
                        }

                        if (it.date?.substringBefore(" ")?.toInt()!! < startDay) {
                            startDay = it.date.substringBefore(" ").toInt()
                        }


                        if (it.intensity != "") {
                            initialDate = date
                            val eventObjects = EventObjects(it.id, "     ", date)

                            if (it.symptom == "Bleeding") {
                                eventObjects.color = yellow
                            } else {
                                eventObjects.color = green
                            }
                            mEvents.add(eventObjects)

                            if (prefs.getOvulationEnabled()) {
                                val eventObjects2 = EventObjects(
                                    it.id + 1,
                                    "",
                                    dateFormat("$startDay ${date?.month?.plus(1)}")?.time?.minus(86400000 * 13)?.let { it1 -> Date(it1) })
                                eventObjects2.color = ov
                                mEvents.add(eventObjects2)

                                val eventOv2 = EventObjects(
                                    it.id + 1,
                                    "",
                                    dateFormat("$startDay ${date?.month?.plus(1)}")?.time?.minus(86400000 * 12)?.let { it1 -> Date(it1) })
                                eventObjects2.color = ov
                                mEvents.add(eventOv2)

                                val eventOv3 = EventObjects(
                                    it.id + 1,
                                    "",
                                    dateFormat("$startDay ${date?.month?.plus(1)}")?.time?.minus(86400000 * 11)?.let { it1 -> Date(it1) })
                                eventObjects2.color = ov
                                mEvents.add(eventOv3)

                                val eventOv4 = EventObjects(
                                    it.id + 1,
                                    "",
                                    dateFormat("$startDay ${date?.month?.plus(1)}")?.time?.minus(86400000 * 10)?.let { it1 -> Date(it1) })
                                eventObjects2.color = ov
                                mEvents.add(eventOv4)

                                val eventOv5 = EventObjects(
                                    it.id + 1,
                                    "",
                                    dateFormat("$startDay ${date?.month?.plus(1)}")?.time?.minus(86400000 * 9)?.let { it1 -> Date(it1) })
                                eventObjects2.color = ov
                                mEvents.add(eventOv5)

                                val eventOv6 = EventObjects(
                                    it.id + 1,
                                    "",
                                    dateFormat("$startDay ${date?.month?.plus(1)}")?.time?.minus(86400000 * 8)?.let { it1 -> Date(it1) })
                                eventObjects2.color = ov
                                mEvents.add(eventOv6)


                            }

                            if (prefs.getPmsEnabled()) {
                                val eventPms1 = EventObjects(
                                    it.id + 2,
                                    "",
                                    dateFormat("$startDay ${date?.month?.plus(1)}")?.time?.minus(
                                        86400000 * 5
                                    )?.let { it1 -> Date(it1) })
                                eventPms1.color = pms
                                val eventPms2 = EventObjects(
                                    it.id + 3,
                                    "",
                                    dateFormat("$startDay ${date?.month?.plus(1)}")?.time?.minus(
                                        86400000 * 4
                                    )?.let { it1 -> Date(it1) })
                                eventPms2.color = pms
                                val eventPms3 = EventObjects(
                                    it.id + 4,
                                    "",
                                    dateFormat("$startDay ${date?.month?.plus(1)}")?.time?.minus(
                                        86400000 * 3
                                    )?.let { it1 -> Date(it1) })
                                eventPms3.color = pms
                                val eventPms4 = EventObjects(
                                    it.id + 5,
                                    "",
                                    dateFormat("$startDay ${date?.month?.plus(1)}")?.time?.minus(
                                        86400000 * 2
                                    )?.let { it1 -> Date(it1) })
                                eventPms4.color = pms
                                val eventPms5 = EventObjects(
                                    it.id + 6,
                                    "",
                                    dateFormat("$startDay ${date?.month?.plus(1)}")?.time?.minus(
                                        86400000 * 1
                                    )?.let { it1 -> Date(it1) })
                                eventPms5.color = pms

                                mEvents.add(eventPms1)
                                mEvents.add(eventPms2)
                                mEvents.add(eventPms3)
                                mEvents.add(eventPms4)
                                mEvents.add(eventPms5)

                            }


                        }
                    }
                }
                withContext(Main) {
                    binding?.progressBar?.isVisible = false
                    binding?.layoutCalender?.removeAllViews()
                    binding?.layoutCalender?.orientation = LinearLayout.VERTICAL

                    val calendarCustomView = CalendarCustomView(requireContext(), mEvents)
                    val layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT
                    )
                    calendarCustomView.layoutParams = layoutParams
                    binding?.layoutCalender?.addView(calendarCustomView)
                    calendarCustomView.calendarGridView.onItemClickListener =
                        OnItemClickListener { adapterView, view, i, l ->
                            Log.i("TLogs", "onViewCreated: $l ${MainActivity.month}")
                            if (adapterView.adapter.getView(l.toInt(), null, null).alpha == 0.4f) {
                                Log.d("hello", "hello")
                            } else {
                                val today = Calendar.getInstance()
                                today.time = Date()
                                val tapedDay = Calendar.getInstance()
                                tapedDay.time = adapterView.adapter.getItem(l.toInt()) as Date
                                val sameDay =
                                    tapedDay[Calendar.YEAR] == tapedDay[Calendar.YEAR] && today[Calendar.DAY_OF_YEAR] == tapedDay[Calendar.DAY_OF_YEAR]
                                if (today.after(tapedDay) && !sameDay) {
                                    Toast.makeText(
                                        requireContext(),
                                        "You can't select previous date.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    adapterView.adapter.getView(l.toInt(), null, null)

                                } else {
                                    val action =
                                        HomeFragmentDirections.actionHomeFragmentToSymptomsFragment("$l ${MainActivity.month}")
                                    findNavController().navigate(action)
                                }
                            }
                        }
                    //calendarCustomView.setRangesOfDate(makeDateRanges());
                }
            } else {
                withContext(Main) {
                    binding?.progressBar?.isVisible = false
                    binding?.layoutCalender?.removeAllViews()
                    binding?.layoutCalender?.orientation = LinearLayout.VERTICAL

                    val calendarCustomView = CalendarCustomView(requireContext(), mEvents)
                    val layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT
                    )
                    calendarCustomView.layoutParams = layoutParams
                    binding?.layoutCalender?.addView(calendarCustomView)
                    calendarCustomView.calendarGridView.onItemClickListener =
                        OnItemClickListener { adapterView, view, i, l ->
                            Log.i("TLogs", "onViewCreated: $l ${MainActivity.month}")
                            if (adapterView.adapter.getView(l.toInt(), null, null).alpha == 0.4f) {
                                Log.d("hello", "hello")
                            } else {
                                val today = Calendar.getInstance()
                                today.time = Date()
                                val tapedDay = Calendar.getInstance()
                                tapedDay.time = adapterView.adapter.getItem(l.toInt()) as Date
                                val sameDay =
                                    tapedDay[Calendar.YEAR] == tapedDay[Calendar.YEAR] && today[Calendar.DAY_OF_YEAR] == tapedDay[Calendar.DAY_OF_YEAR]
                                if (today.after(tapedDay) && !sameDay) {
                                    Toast.makeText(
                                        requireContext(),
                                        "You can't select previous date.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    adapterView.adapter.getView(l.toInt(), null, null)

                                } else {
                                    val action =
                                        HomeFragmentDirections.actionHomeFragmentToSymptomsFragment("-1 -1")
                                    findNavController().navigate(action)
                                }
                            }
                        }
                    //calendarCustomView.setRangesOfDate(makeDateRanges());
                }
            }

        }


    }

    private fun moveToNext(destination: String) {
        if (findNavController().currentDestination?.id == R.id.homeFragment) {
            when (destination) {
                "Symptoms" -> {
                    findNavController().navigate(R.id.action_homeFragment_to_symptomsFragment)
                }
                "Settings" -> {
                    findNavController().navigate(R.id.action_homeFragment_to_settingsFragment)
                }
            }
        }
    }

    private fun fragmentBackPress() {
        callback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (exit) {
                    requireActivity().finishAndRemoveTask()
                } else {
                    Toast.makeText(
                        context,
                        getString(R.string.press_again_to_exit),
                        Toast.LENGTH_SHORT
                    ).show()
                    exit = true
                    countDown = object : CountDownTimer(3000, 1000) {
                        override fun onTick(millisUntilFinished: Long) {
                        }

                        override fun onFinish() {
                            exit = false
                        }
                    }
                    countDown.start()

                }
            }
        }
        requireActivity().onBackPressedDispatcher.addCallback(requireActivity(), callback)
    }

    override fun onDestroyView() {
        super.onDestroyView()
//        requireActivity().window.clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        _binding = null
    }

    override fun onDestroy() {
        super.onDestroy()
        if (this::callback.isInitialized) {
            callback.isEnabled = false
            callback.remove()
        }
    }

    override fun onSelectedDayChange(p0: CalendarView, p1: Int, p2: Int, p3: Int) {
        Log.i("TLogs", "onDateSelected: ")

        val action = HomeFragmentDirections.actionHomeFragmentToSymptomsFragment("$p3 ${p2 + 1}")

        findNavController().navigate(action)
    }


    private fun makeDateRanges(): List<EventObjects> {
        if (lastDate?.after(initialDate) == true) {
            start = initialDate
            end = lastDate
        } else {
            start = lastDate
            end = initialDate
        }
        val eventObjectses: MutableList<EventObjects> = ArrayList()
        val gcal = GregorianCalendar()
        gcal.time = start
        while (!gcal.time.after(end)) {
            val d = gcal.time
            val eventObject = EventObjects("", d)
            //eventObject.color = resources.getColor(R.color.green)

            eventObjectses.add(eventObject)
            gcal.add(Calendar.DATE, 1)
        }
        return eventObjectses
    }

    private fun dateFormat(date: String): Date? {

        val day = date.substringBefore(" ")


        val month = date.substringAfter(" ")
        val year = "2022"

//        String dtStart = "2022-08-07T09:27:37Z";

//        String dtStart = "2022-08-07T09:27:37Z";
        val dtStart = year + "-" + month + "-" + day + "T00:00:00Z"
        val format = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
        return try {
            val newDate = format.parse(dtStart)
            Log.i("MyTag", "onCreate: $newDate")
            newDate
        } catch (e: ParseException) {
            Log.i("MyTag", "onCreate: ")
            e.printStackTrace()
            null
        }
    }


}