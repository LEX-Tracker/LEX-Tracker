package com.lex

import android.app.Application

//@HiltAndroidApp
class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()

    }
}