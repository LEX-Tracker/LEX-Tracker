package com.lex.database

import androidx.lifecycle.LiveData
import com.lex.models.DataSymptoms
import com.lex.models.SymptomModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MyRepository(val myDao: MyDao) {

    val readAllData: LiveData<List<SymptomModel>> = myDao.getAllData()

    fun addData(listData: ArrayList<SymptomModel>) {
        CoroutineScope(Dispatchers.IO).launch {
            myDao.addData(listData)
        }
    }

    fun updateData(newIntensity: String, date: String, symptom:String) {
        CoroutineScope(Dispatchers.IO).launch {
            myDao.updateValues(newIntensity, date, symptom)
        }
    }




}