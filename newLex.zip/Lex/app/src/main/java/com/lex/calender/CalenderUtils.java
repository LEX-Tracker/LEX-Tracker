package com.lex.calender;

/**
 * Created by Name : Ali Ahmed
 * Email: aliahmedaiub@gmail.com
 * on 10/18/2017.
 */

public interface CalenderUtils {
    public void nextMonth();
    public void previousMonths();
}
