package com.lex.models

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import androidx.sqlite.db.SimpleSQLiteQuery
import com.lex.database.MyDao
import com.lex.database.MyDatabase
import com.lex.database.MyRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MyViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: MyRepository
    val readAllData: LiveData<List<SymptomModel>>
    val myDatabase: MyDatabase
    val myDao: MyDao

    init {
        myDatabase = MyDatabase.getDatabase(application)
        myDao = myDatabase.myDao()
        repository = MyRepository(myDao)
        readAllData = repository.readAllData
    }

    fun addData(listData: ArrayList<SymptomModel>) {
        viewModelScope.launch {
            repository.addData(listData)
        }
    }

    fun updateData(newIntensity: String, date: String, symptom: String) {
        viewModelScope.launch {
            repository.updateData(newIntensity, date, symptom)
        }
    }

    suspend fun pushCustomerData(columns:StringBuilder,values:StringBuilder) = withContext(Dispatchers.IO){
        val query = SimpleSQLiteQuery(
            "INSERT INTO sym_table ($columns) values($values)",
            arrayOf()
        )
        try {
            myDao.insertDataRawFormat(query)
        }catch (e: Exception){
            Log.i("Logs", "pushCustomerData: ${e.message}")
        }
    }


}